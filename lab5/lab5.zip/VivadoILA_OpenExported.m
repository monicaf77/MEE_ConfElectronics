delimiter = ',';
startRow = 2;
ILA_depth = 1024;
endRow = ILA_depth+1;
formatSpec = '%s%s%s%s%s%s%s%s%s%[^\n\r]';
filename = 'C:\Xilinx\MEE_EC\labs\lab5_ILA\data2.csv'
fileID = fopen(filename,'r');

dataArray = textscan(fileID, formatSpec, endRow(1)-startRow(1)+1, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines', startRow(1)-1, 'ReturnOnError', false);
for block=2:length(startRow)
    frewind(fileID);
    dataArrayBlock = textscan(fileID, formatSpec, endRow(block)-startRow(block)+1, 'Delimiter', delimiter, 'EmptyValue' ,NaN,'HeaderLines', startRow(block)-1, 'ReturnOnError', false);
    for col=1:length(dataArray)
        dataArray{col} = [dataArray{col};dataArrayBlock{col}];
    end
end
fclose(fileID);   %% Close the text file.
baseband_rect = dataArray{:, 4};
baseband_rcos = dataArray{:, 5};
passband_ask = dataArray{:, 9};


for ii = 2:ILA_depth
        bin_string_baseband_rect = cell2mat(baseband_rect(ii));
        bin_vec_baseband_rect(ii)=str2num(bin_string_baseband_rect); %binary string to num vector
        
        bin_string_baseband_rcos = cell2mat(baseband_rcos(ii));
        bin_vec_baseband_rcos(ii)=str2num(bin_string_baseband_rcos); %binary string to num vector
		
		bin_string_passband_ask = cell2mat(passband_ask(ii));
        bin_vec_passband_ask(ii)=str2num(bin_string_passband_ask); %binary string to num vector
end
